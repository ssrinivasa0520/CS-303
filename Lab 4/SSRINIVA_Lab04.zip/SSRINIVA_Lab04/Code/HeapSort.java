import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

public class HeapSort {
	
	public static void maxHeapify(List<Integer> arr, int N, int i)
    {
        int largest = i;
        int l = 2 * i + 1;
        int r = 2 * i + 2;
 
        if (l < N && arr.get(l) > arr.get(largest))
            largest = l;
 
        if (r < N && arr.get(r) > arr.get(largest))
            largest = r;
 
        if (largest != i) {
            int swap = arr.get(i);
            arr.set(i, arr.get(largest));
            arr.set(largest, swap);
 
            maxHeapify(arr, N, largest);
        }
    }
	
	public static void heapSort(List<Integer> arr)
    {
		int N = arr.size();
        buildMaxHeap(arr);
 
        for (int i = N - 1; i > 0; i--) {
            int temp = arr.get(0);
            arr.set(0, arr.get(i));
            arr.set(i, temp);
            maxHeapify(arr, i, 0);
        }
    }
	
	public static void buildMaxHeap(List<Integer> arr) {
		int N = arr.size();
		 
        for (int i = N / 2 - 1; i >= 0; i--)
            maxHeapify(arr, N, i);
	}
	
	public static void test() {
		List<Integer> A1 = Arrays.asList(33647, 223, 2, 1, 1003, 67, 345, 3495, 2, 234, 567, 23324234, 435, 656);
		heapSort(A1);
		System.out.println(A1);
	}

	public static List<Integer> readElementsFromFile(String fileName) {
		List<Integer> elements = new ArrayList<Integer>();

		try (Scanner fileScanner = new Scanner(Paths.get(fileName))) {
			while (fileScanner.hasNextLine()) {
				String line = fileScanner.nextLine();
				elements.addAll(
						Arrays.asList(line.split(",")).stream().map(Integer::valueOf).collect(Collectors.toList()));
			}
			fileScanner.close();
		} catch (Exception e) {
			System.out.println("Error: " + e.toString());
		}
		return elements;
	}
	
	public static void driver() {

		List<Integer> sizes = Arrays.asList(1000, 2500, 5000, 10_000, 25_000, 50_000, 100_000, 250_000, 500_000);
		Instant start, finish;
		long timeElapsed;

		System.out.format("%-30s %-30s\n", "Dataset Size", "Time (milliseconds)");

		for (Integer s : sizes) {
			List<Integer> elements = readElementsFromFile(String.format("%d.txt", s));
			start = Instant.now();
			heapSort(elements);
			finish = Instant.now();
			timeElapsed = Duration.between(start, finish).toMillis();
			System.out.format("%-30d %-30d\n", s, timeElapsed);
		}
	}
	
	public static void main(String args[]) {
		// test();
		driver();
	}
}
