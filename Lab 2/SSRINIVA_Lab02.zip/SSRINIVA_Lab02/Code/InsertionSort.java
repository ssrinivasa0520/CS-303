import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

public class InsertionSort {
	
	public static void insertionSort(List<Integer> arr) {
		int N = arr.size();
		
		int temp, currLoc;
        for (int i=1; i<N; i++){
            currLoc = i;
            while (currLoc > 0 && arr.get(currLoc - 1) > arr.get(currLoc)){
                temp = arr.get(currLoc);
                arr.set(currLoc, arr.get(currLoc - 1));
                arr.set(currLoc - 1, temp);
                currLoc--;
            }
        } 
	}
	
	public static List<Integer> readElementsFromFile(String fileName) {
		List<Integer> elements = new ArrayList<Integer>();
		
		try (Scanner fileScanner = new Scanner(Paths.get(fileName))) {
			while(fileScanner.hasNextLine()) {
				String line = fileScanner.nextLine();
				elements.addAll(Arrays.asList(line.split(",")).stream().map(Integer::valueOf)
						.collect(Collectors.toList()));
			}
			fileScanner.close();
		} catch (Exception e) {
			System.out.println("Error: " + e.toString());
		}
		return elements;
	}
	
	public static void main(String args[]) {
		
		List<Integer> sizes = Arrays.asList(1000, 2500, 5000, 10_000, 25_000, 50_000, 100_000, 250_000, 500_000,
														 1_000_000);
		Instant start, finish;
		long timeElapsed;
		
		System.out.format("%-30s %-30s\n", "Dataset Size", "Time (nanoseconds)");
		
		for(Integer s: sizes) {
			List<Integer> elements = readElementsFromFile(String.format("%d.txt", s));
			start = Instant.now();
			insertionSort(elements);
			finish = Instant.now();
			timeElapsed = Duration.between(start, finish).toNanos();
			System.out.format("%-30d %-30d\n", s, timeElapsed);
		}
	}
}
