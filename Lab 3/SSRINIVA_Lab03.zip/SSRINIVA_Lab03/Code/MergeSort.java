import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

public class MergeSort {
	
	public static void mergeSort(List<Integer> A, List<Integer> temp, int p, int r) {
		if (p < r) {
			int q = (p + r) / 2;
			mergeSort(A, temp, p, q);
			mergeSort(A, temp, q + 1, r);
			merge(A, temp, p, q, r);
		}
	}
	
	public static void mergeSortModified(List<Integer> A, List<Integer> temp, int p, int r, int limit) {
		if (p < r) {
			if((r - p) > limit) {
				int q = (p + r) / 2;
				mergeSortModified(A, temp, p, q, limit);
				mergeSortModified(A, temp, q + 1, r, limit);
				merge(A, temp, p, q, r);
			} else {
				insertionSort(A, p, r);
			}
		}
	}

	public static void merge(List<Integer> A, List<Integer> temp, int p, int q, int r) {
		int i = p;
		int j = q + 1;
		for (int k = p; k <= r; k++)
			temp.set(k, A.get(k));
		for (int k = p; k <= r; k++) {
			if (i > q) {
				A.set(k, temp.get(j));
				j++;
			} else if (j > r) {
				A.set(k, temp.get(i));
				i++;
			} else if (temp.get(j) < temp.get(i)) {
				A.set(k, temp.get(j));
				j++;
			} else {
				A.set(k, temp.get(i));
				i++;
			}
		}
	}

	public static void insertionSort(List<Integer> A, int p, int q) {
		for (int j = p + 1; j <= q; j++) {
			int key = A.get(j);
			int i = j - 1;
			while (i >= p && A.get(i) > key) {
				A.set(i + 1, A.get(i));
				i--;
			}
			A.set(i + 1, key);
		}
	}

	public static void test() {
		List<Integer> A1 = Arrays.asList(33647, 223, 2, 1, 1003, 67, 345, 3495, 2, 234, 567, 23324234, 435, 656);
		List<Integer> A2 = new ArrayList<>(A1);
		List<Integer> A3 = new ArrayList<>(A1);
		List<Integer> temp;
		temp = new ArrayList<>(A1);
		mergeSort(A1, temp, 0, A1.size() - 1);
		insertionSort(A2, 0, A2.size() - 1);
		temp = new ArrayList<>(A3);
		mergeSortModified(A3, temp, 0, A3.size() - 1, 5);
		System.out.println(A1);
		System.out.println(A2);
		System.out.println(A3);
	}

	public static List<Integer> readElementsFromFile(String fileName) {
		List<Integer> elements = new ArrayList<Integer>();

		try (Scanner fileScanner = new Scanner(Paths.get(fileName))) {
			while (fileScanner.hasNextLine()) {
				String line = fileScanner.nextLine();
				elements.addAll(
						Arrays.asList(line.split(",")).stream().map(Integer::valueOf).collect(Collectors.toList()));
			}
			fileScanner.close();
		} catch (Exception e) {
			System.out.println("Error: " + e.toString());
		}
		return elements;
	}

	public static void driver1() {

		List<Integer> sizes = Arrays.asList(1000, 2500, 5000, 10_000, 25_000, 50_000, 100_000, 250_000, 500_000,
				1_000_000);
		Instant start, finish;
		long timeElapsed;

		System.out.format("%-30s %-30s\n", "Dataset Size", "Time (milliseconds)");

		for (Integer s : sizes) {
			List<Integer> elements = readElementsFromFile(String.format("%d.txt", s));
			start = Instant.now();
			List<Integer> temp = new ArrayList<>(elements);
			mergeSort(elements, temp, 0, elements.size() - 1);
			finish = Instant.now();
			timeElapsed = Duration.between(start, finish).toMillis();
			System.out.format("%-30d %-30d\n", s, timeElapsed);
		}
	}
	
	public static void driver2() {

		List<Integer> sizes = Arrays.asList(1000, 2500, 5000, 10_000, 25_000, 50_000, 100_000, 250_000, 500_000,
				1_000_000);
		List<Integer> limits = Arrays.asList(10, 25, 50, 100);
		Instant start, finish;
		long timeElapsed;

		System.out.format("%-30s", "Dataset Size");
		
		for(Integer limit: limits) {
			System.out.format(" %-30s", "Limit=" + limit);
		}
		
		System.out.println();

		for (Integer s : sizes) {
			List<Integer> elements = readElementsFromFile(String.format("%d.txt", s));
			System.out.format("%-30d", s);
			for(Integer limit: limits) {
				start = Instant.now();
				mergeSortModified(new ArrayList<>(elements), new ArrayList<>(elements), 0, elements.size() - 1, limit);
				finish = Instant.now();
				timeElapsed = Duration.between(start, finish).toMillis();
				System.out.format(" %-30d", timeElapsed);
			}
			System.out.println();
		}
	}

	public static void main(String args[]) {
		// test();
		driver1();
		driver2();
	}

}
