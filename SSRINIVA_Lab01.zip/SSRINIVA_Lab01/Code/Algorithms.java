import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Algorithms {
	
	public static int linearSearch(List<Integer> arr, Integer key) {
		for(int i = 0; i < arr.size(); i++) {
			if(arr.get(i).equals(key)) return i;
		} 
		return -1;
	}
	
	public static int binarySearch(List<Integer> arr, int l, int u, Integer key) {
		if(l > u) return -1;
		int m = (l + u) / 2;
		if(arr.get(m) > key) {
			return binarySearch(arr, l, m - 1, key);
		} else if(arr.get(m) < key) {
			return binarySearch(arr, m + 1, u, key);
		} else return m;
	}
	
	public static void driver1() {
		List<Integer> arr = Arrays.asList(22, 45, 65, 3, 1, 903, 43, 5);
		int n1 = 45, n2 = 75, n3 = 65, n4 = 5;
		Collections.sort(arr);
		System.out.println(arr);
		int linearResult1 = linearSearch(arr, n1);
		int linearResult2 = linearSearch(arr, n2);
		int binaryResult1 = binarySearch(arr, 0, arr.size() - 1, n3);
		int binaryResult2 = binarySearch(arr, 0, arr.size() - 1, n4);
		
		System.out.format("%d found at %d and %d found at %d\n", n1, linearResult1, n2, linearResult2);
		System.out.format("%d found at %d and %d found at %d\n", n3, binaryResult1, n4, binaryResult2);
		
	}
	
	public static void main(String args[]) {
		driver1();
	}
}
