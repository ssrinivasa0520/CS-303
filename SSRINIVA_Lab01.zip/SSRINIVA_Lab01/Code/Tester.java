import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
import java.time.*;

public class Tester {
	public static List<Integer> getNRandomNos(int n) {
		Random rand = new Random();
		List<Integer> numbers = new ArrayList<>();
		for(int i = 0; i < n; i++) {
			numbers.add(rand.nextInt(1000));
		}
		return numbers;
	}
	
	public static Map<Integer, List<Integer>> generate2NDatasets(int N) {
		Map<Integer, List<Integer>> datasets = new HashMap<>();
		for(int i = 4; i <= N; i++) {
			Integer n = (int)Math.pow(2, i);
			datasets.put(i, getNRandomNos(n));
		}
		return datasets;
	}
	
	public static List<Integer> readKeysFromFile() {
		List<Integer> keys = new ArrayList<Integer>();
		
		try (Scanner fileScanner = new Scanner(Paths.get("input_1000.txt"))) {
			while(fileScanner.hasNextLine()) {
				String line = fileScanner.nextLine();
				keys.addAll(Arrays.asList(line.split(",")).stream().map(Integer::valueOf).collect(Collectors.toList()));
			}
			fileScanner.close();
		} catch (Exception e) {
			System.out.println("Error: " + e.toString());
		}
		return keys;
	}
	
	public static void driver2() {
		List<Integer> keys = readKeysFromFile();
		Map<Integer, List<Integer>> datasets = generate2NDatasets(20);
		Instant start, finish;
		
		for(Integer N = 4; N <= 20; N++) {
			List<Integer> dataset = datasets.get(N);
			long timeElapsed;
			
			System.out.format("2^%-5d", N);
			
			start = Instant.now();
			for(Integer key: keys) {
				Algorithms.linearSearch(dataset, key);
			}
			finish = Instant.now();
			timeElapsed = Duration.between(start, finish).toNanos() / 1000;
			System.out.format("%12d", timeElapsed);
			
			Collections.sort(dataset);
			start = Instant.now();
			for(Integer key: keys) {
				Algorithms.binarySearch(dataset, 0, dataset.size() - 1, key);
			}
			finish = Instant.now();
			timeElapsed = Duration.between(start, finish).toNanos() / 1000;
			System.out.format("%12d", timeElapsed);
			
			System.out.println();
		}
	}
	
	public static void main(String args[]) {
		driver2();
	}
}
