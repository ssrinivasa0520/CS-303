import java.nio.file.Paths;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

public class QuickSort {

	public static void swap(List<Integer> A, Integer dex1, Integer dex2) {
		int temp = A.get(dex1);
		A.set(dex1, A.get(dex2));
		A.set(dex2, temp);
	}

	public static Integer partition(List<Integer> A, Integer p, Integer r) {
		Integer x = A.get(r);
		Integer i = p - 1;
		for (Integer j = p; j <= r - 1; j++) {
			if (A.get(j) <= x) {
				i++;
				swap(A, i, j);
			}
		}
		swap(A, i + 1, r);
		return i + 1;
	}

	public static int median3(List<Integer> A, int left, int right) {
	    int center = (left + right) / 2;

	    if (A.get(left) > A.get(center))
	      swap(A, left, center);

	    if (A.get(left) > A.get(right))
	      swap(A, left, right);

	    if (A.get(center) > A.get(right))
	      swap(A, center, right);

	    swap(A, center, right - 1);
	    return right - 1;
	  }

	public static void quickSort(List<Integer> A, Integer p, Integer r) {
		if (p < r) {
			Integer q = partition(A, p, r);
			quickSort(A, p, q - 1);
			quickSort(A, q + 1, r);

		}
	}
	
	public static void quickSortMedian3(List<Integer> A, Integer p, Integer r) {
		if (p < r) {
			Integer m = median3(A, p, r);
			//swap(A, m, r);
			Integer q = partition(A, p, r);
			quickSort(A, p, q - 1);
			quickSort(A, q + 1, r);

		}
	}

	public static void test() {
		List<Integer> A1 = Arrays.asList(33647, 223, 2, 1, 1003, 67, 345, 3495, 2, 234, 567, 23324234, 435, 656);
		quickSort(A1, 0, A1.size() - 1);
		System.out.println(A1);
		List<Integer> A2 = Arrays.asList(231,234,23412,22,123425,1,345345,34,578797,2,45,4,35,457,36,7356,7,2465);
		quickSortMedian3(A2, 0, A2.size() - 1);
		System.out.println(A2);
	}
	
	public static List<Integer> readElementsFromFile(String fileName, String seperator) {
		List<Integer> elements = new ArrayList<Integer>();

		try (Scanner fileScanner = new Scanner(Paths.get(fileName))) {
			while (fileScanner.hasNextLine()) {
				String line = fileScanner.nextLine();
				elements.addAll(
						Arrays.asList(line.trim().split(seperator)).stream().map(Integer::valueOf).collect(Collectors.toList()));
			}
			fileScanner.close();
		} catch (Exception e) {
			System.out.println("Error: " + e.toString());
		}
		return elements;
	}
	
	public static void driver1() {

		List<Integer> sizes = Arrays.asList(16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192);
		Instant start, finish;
		long timeElapsed;

		System.out.format("%-30s %-30s\n", "Dataset Size", "Time (milliseconds)");

		for (Integer s : sizes) {
			List<Integer> elements = readElementsFromFile(String.format("input_%d.txt", s), " ");
			start = Instant.now();
			quickSort(elements, 0, elements.size() - 1);
			finish = Instant.now();
			timeElapsed = Duration.between(start, finish).toMillis();
			System.out.format("%-30d %-30d\n", s, timeElapsed);
		}
	}

	public static void driver2() {

		List<String> sizes = Arrays.asList("Sorted", "ReversedSorted", "Random");
		Instant start, finish;
		long timeElapsed;

		System.out.format("%-30s %-30s\n", "Dataset Size", "Time (milliseconds)");

		for (String s : sizes) {
			List<Integer> elements = readElementsFromFile(String.format("Input_%s.txt", s), " ");
			start = Instant.now();
			quickSort(elements, 0, elements.size() - 1);
			finish = Instant.now();
			timeElapsed = Duration.between(start, finish).toMillis();
			System.out.format("%-30s %-30d\n", s, timeElapsed);
		}
	}
	
	public static void driver3() {

		List<Integer> sizes = Arrays.asList(16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192);
		Instant start, finish;
		long timeElapsed;

		System.out.format("%-30s %-30s\n", "Dataset Size", "Time (milliseconds)");

		for (Integer s : sizes) {
			List<Integer> elements = readElementsFromFile(String.format("input_%d.txt", s), " ");
			start = Instant.now();
			quickSortMedian3(elements, 0, elements.size() - 1);
			finish = Instant.now();
			timeElapsed = Duration.between(start, finish).toMillis();
			System.out.format("%-30d %-30d\n", s, timeElapsed);
		}
	}
	
	public static void driver4() {

		List<Integer> sizes = Arrays.asList(1000, 2500, 5000, 10_000, 25_000, 50_000, 100_000, 250_000, 500_000);
		Instant start, finish;
		long timeElapsed;

		System.out.format("%-30s %-30s\n", "Dataset Size", "Time (milliseconds)");

		for (Integer s : sizes) {
			List<Integer> elements = readElementsFromFile(String.format("%d.txt", s), ",");
			start = Instant.now();
			quickSort(elements, 0, elements.size() - 1);
			finish = Instant.now();
			timeElapsed = Duration.between(start, finish).toMillis();
			System.out.format("%-30d %-30d\n", s, timeElapsed);
		}
	}
	
	public static void main(String args[]) {
		//test();
		driver1();
		driver2();
		driver3();
		driver4();
	}
}
